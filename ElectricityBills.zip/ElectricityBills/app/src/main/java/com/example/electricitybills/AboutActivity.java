package com.example.electricitybills;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Enable clickable links in the TextView
        TextView tvLink = findViewById(R.id.tvClickableLink);
        tvLink.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
